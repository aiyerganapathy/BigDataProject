import cgi
import json
print ("Content-Type: application/json\n")
dict_={}
temperature={}
temperature['min']=34
temperature['max']=70
dict_['temp']=temperature
wind={}
wind['max']=10
wind['min']=0
dict_['wind']=wind
visibility={}
visibility['min']=0
visibility['max']=10
dict_['visibility']=visibility
json_string = json.dumps(dict_)
print (json_string)

